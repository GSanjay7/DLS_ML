"""Sanity tests for the MoE classifier."""
from __future__ import annotations

import numpy as np
import pandas as pd

from dlsmp.moe import MoEDLSClassifier, DEFAULT_EXPERTS, CLASS_NAMES
from dlsmp.domain_adapt import coral_align


def _tiny_frame():
    rng = np.random.default_rng(0)
    n = 30
    df = pd.DataFrame({
        "mean_intensity_kcps":   rng.uniform(50, 800, n),
        "hydrodynamic_diameter_nm": rng.uniform(50, 3000, n),
        "polydispersity_pct":    rng.uniform(1, 300, n),
        "d_stokes_einstein_nm":  rng.uniform(50, 3000, n),
        "intercept_g1sq":        rng.uniform(0.8, 1.0, n),
        "fit_error":             rng.uniform(1e-5, 1e-2, n),
        "peak1_area_pct":        rng.uniform(50, 100, n),
        "cumulants_unreliable":  rng.integers(0, 2, n),
        "int_frac_sub_10nm":     rng.uniform(0, 0.3, n),
        "int_frac_10_100nm":     rng.uniform(0, 0.3, n),
        "int_frac_100_1000nm":   rng.uniform(0, 0.5, n),
        "int_frac_1_10um":       rng.uniform(0, 0.3, n),
        "vol_frac_10_100nm":     rng.uniform(0, 0.3, n),
        "vol_frac_100_1000nm":   rng.uniform(0, 0.5, n),
        "int_log10d_mean":       rng.uniform(1, 4, n),
        "int_log10d_std":        rng.uniform(0.1, 1.0, n),
        "int_log10d_skew":       rng.uniform(-1, 1, n),
        "int_log10d_kurt":       rng.uniform(-1, 3, n),
        "int_D10":               rng.uniform(10, 500, n),
        "int_D50":               rng.uniform(50, 2000, n),
        "int_D90":               rng.uniform(200, 5000, n),
        "int_n_modes":           rng.integers(1, 4, n),
        "int_entropy":           rng.uniform(1, 5, n),
    })
    y = rng.integers(0, 3, n)
    return df, y


def test_coral_matches_moments():
    rng = np.random.default_rng(0)
    X_real = rng.normal(0, 1, size=(30, 5)) @ np.diag([2, 1, 0.5, 1.5, 0.3])
    X_syn = rng.normal(2, 0.5, size=(200, 5))
    X_aligned = coral_align(X_syn, X_real)
    assert np.allclose(X_aligned.mean(axis=0), X_real.mean(axis=0), atol=1e-6)
    assert np.allclose(X_aligned.std(axis=0), X_real.std(axis=0), atol=0.05)


def test_moe_fit_predict_shape():
    df, y = _tiny_frame()
    m = MoEDLSClassifier(seed=42, gate_epochs=50, gate_on_synthetic=False)
    m.fit(df, y)
    proba = m.predict_proba(df)
    assert proba.shape == (len(df), 3)
    assert np.allclose(proba.sum(axis=1), 1.0, atol=1e-5)
    preds = m.predict(df)
    assert set(preds).issubset({0, 1, 2})


def test_moe_expert_gates_sum_to_one():
    df, y = _tiny_frame()
    m = MoEDLSClassifier(seed=42, gate_epochs=50, gate_on_synthetic=False)
    m.fit(df, y)
    gates = m.expert_gates(df)
    assert gates.shape == (len(df), len(DEFAULT_EXPERTS))
    assert np.allclose(gates.sum(axis=1), 1.0, atol=1e-5)


if __name__ == "__main__":
    test_coral_matches_moments()
    test_moe_fit_predict_shape()
    test_moe_expert_gates_sum_to_one()
    print("All tests passed.")
