"""Sanity tests for the feature extraction and engineering."""
from __future__ import annotations

import numpy as np
import pandas as pd

from dlsmp.features import (spectrum_features,
                            stokes_einstein_diameter_nm,
                            engineer_all)


def test_stokes_einstein_water_at_25C():
    d = stokes_einstein_diameter_nm(0.145)
    assert 3300 < d < 3500, f"Expected ~3376 nm, got {d:.1f}"


def test_stokes_einstein_returns_nan_for_zero():
    assert np.isnan(stokes_einstein_diameter_nm(0.0))
    assert np.isnan(stokes_einstein_diameter_nm(-1.0))
    assert np.isnan(stokes_einstein_diameter_nm(None))


def test_spectrum_features_shape():
    d_nm = np.logspace(-1, 4, 142)
    w = np.zeros_like(d_nm); w[70] = 100.0
    feats = spectrum_features(d_nm, w, "int")
    expected_keys = {"int_log10d_mean", "int_log10d_std", "int_log10d_skew",
                     "int_log10d_kurt", "int_D10", "int_D50", "int_D90",
                     "int_n_modes", "int_entropy", "int_l2",
                     "int_frac_sub_10nm", "int_frac_10_100nm",
                     "int_frac_100_1000nm", "int_frac_1_10um"}
    assert set(feats.keys()) == expected_keys


def test_spectrum_features_bands_bounded():
    """The four band fractions cover 0-10 um. Their sum is <= 1 because
    the grid extends to 19 um; anything above 10 um is not counted."""
    d_nm = np.logspace(-1, np.log10(19095), 142)
    rng = np.random.default_rng(0)
    w = rng.uniform(0, 100, size=len(d_nm))
    feats = spectrum_features(d_nm, w, "int")
    band_sum = (feats["int_frac_sub_10nm"] + feats["int_frac_10_100nm"]
                + feats["int_frac_100_1000nm"] + feats["int_frac_1_10um"])
    assert 0.0 < band_sum <= 1.0 + 1e-9


def test_engineer_all_returns_62_columns():
    df = engineer_all("data/processed/dls_features.csv",
                      "data/processed/size_distributions.npz")
    n_engineered = df.shape[1] - 17
    assert n_engineered >= 45


def test_cumulants_unreliable_flag():
    df = engineer_all("data/processed/dls_features.csv",
                      "data/processed/size_distributions.npz")
    assert "cumulants_unreliable" in df.columns
    n_unreliable = df["cumulants_unreliable"].sum()
    assert 5 <= n_unreliable <= 20


if __name__ == "__main__":
    test_stokes_einstein_water_at_25C()
    test_stokes_einstein_returns_nan_for_zero()
    test_spectrum_features_shape()
    test_spectrum_features_bands_bounded()
    test_engineer_all_returns_62_columns()
    test_cumulants_unreliable_flag()
    print("All tests passed.")
