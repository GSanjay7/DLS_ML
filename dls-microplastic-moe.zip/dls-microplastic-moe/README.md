# dls-microplastic-moe

Mixture-of-experts classifier and synthetic-data pipeline for the paper
*"Machine learning-assisted dynamic light scattering for rapid screening of
sub-micron plastic particulates in drinking water"*.

This repository contains the raw feature matrix, the synthetic augmentation
cohort, the trained model artefacts, and every Python module needed to
reproduce the results in the paper from a fresh checkout.

## Contents

```
dls-microplastic-moe/
├── dlsmp/                                package: feature extraction, MoE, training, prediction
│   ├── extract_features.py               DynaPro NanoStar XLSX -> scalars + 142-bin distributions
│   ├── features.py                       distribution moments, band fractions, Stokes-Einstein
│   ├── augment.py                        multi-modal mixture + bootstrap-perturb synthetic generator
│   ├── domain_adapt.py                   CORAL covariance alignment
│   ├── moe.py                            mixture-of-experts classifier (sklearn-compatible)
│   ├── train.py                          train and save the deployed model bundles
│   ├── evaluate.py                       repeat cross-validation, LOGO, transfer benchmarks
│   ├── predict.py                        command-line prediction on a new XLSX file
│   ├── inverse_prediction.py             calibration regression against Wei and Chua (2026) SI
│   └── external_validation.py            cross-check with Wei and Chua (2026) polymer references
├── data/
│   ├── processed/                        27-row feature matrix, 142-bin distributions
│   ├── synthetic/                        450-sample augmented cohort
│   └── external/                         Wei and Chua (2026) processed reference table
├── models/                               joblib bundles for the two deployed models
├── scripts/                              figure generation
└── tests/                                sanity tests
```

## Installation

Requires Python 3.13. Install dependencies:

```bash
pip install -r requirements.txt
```

## Reproducing the paper results

The full sequence from a fresh checkout is:

```bash
# 1. Feature extraction from the raw DynaPro NanoStar XLSX exports
python -m dlsmp.extract_features data/raw/dlsresults -o data/processed

# 2. Engineered features (distribution moments, band fractions, cross-checks)
python -m dlsmp.features data/processed/dls_features.csv data/processed/size_distributions.npz \
    -o data/processed/dls_engineered.csv

# 3. Synthetic augmentation
python -m dlsmp.augment data/processed/dls_features.csv data/processed/size_distributions.npz \
    -o data/synthetic/synthetic_augmented.npz

# 4. Train the two deployed models
python -m dlsmp.train

# 5. Reproduce Table 4 of the paper
python -m dlsmp.evaluate

# 6. Wei and Chua (2026) external cross-check (requires data/external/wei_chua_si.xlsx)
python -m dlsmp.external_validation

# 7. Inverse-prediction calibration and per-sample concentration estimates
python -m dlsmp.inverse_prediction
```

Every random seed is fixed at 42. All models write to `models/`, all figures
to `figures/`, and all metrics tables to JSON files at the repository root.

## Predicting on a new measurement

To predict on a new DynaPro NanoStar XLSX export:

```bash
python -m dlsmp.predict path/to/new_measurement.xlsx
python -m dlsmp.predict path/to/folder/           # batch mode
python -m dlsmp.predict --json file.xlsx          # JSON output
```

The output contains: raw Cumulants scalars and the Stokes-Einstein
cross-check; the class prediction of both the primary and shape-only MoE
models with per-expert breakdown and gating weights; and the Milli-Q
anomaly distance.

## Data availability

- Feature matrix and 142-bin distributions: `data/processed/`
- Synthetic augmentation cohort: `data/synthetic/`
- Wei and Chua (2026) supplementary reference data, after our processing:
  `data/external/wei_chua_processed.csv`

The raw DynaPro NanoStar XLSX exports for the 27 measurements are archived
separately at Zenodo under DOI 10.5281/zenodo.14XXXXXX (see paper Section 6).

## Licence

- Code: MIT (see `LICENSE`).
- Data: CC-BY 4.0.

## Citation

If you use this repository, please cite the paper:

> Ganpisetti, R., Giridharan, S., Biswas, P. and Chandankere, R.,
> "Machine learning-assisted dynamic light scattering for rapid screening
> of sub-micron plastic particulates in drinking water", 2026.
