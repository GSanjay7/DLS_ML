"""Inverse prediction: from DLS intensity to equivalent polymer concentration.

Forward log-log calibration on the Wei and Chua (2026) reference cohort:

    log10(I) = alpha + beta * log10(c)

Inverse prediction:

    c_hat = 10 ** ((log10(I) - alpha) / beta)

Confidence intervals on c_hat are obtained by parametric bootstrap: N
resamples of the reference rows with replacement, refit the calibration
on each resample, read off the inverse prediction. The 2.5 and 97.5
percentiles give the 95% CI. The bootstrap is preferred over Fieller's
theorem because residual homoscedasticity is only approximate in raw
units and the log-log transformation does not fully resolve it.

The result is a per-sample equivalent polystyrene concentration in ng/mL
with a 95% confidence interval, for each of the 27 measurements.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)
N_BOOT = 2000
ALPHA_CI = 0.05


def fit_loglog(c: np.ndarray, I: np.ndarray) -> tuple[float, float, float]:
    """OLS in log10 space. Returns alpha (intercept), beta (slope), R^2."""
    mask = (c > 0) & (I > 0)
    lc, lI = np.log10(c[mask]), np.log10(I[mask])
    beta, alpha = np.polyfit(lc, lI, 1)
    pred = alpha + beta * lc
    ss_res = ((lI - pred) ** 2).sum()
    ss_tot = ((lI - lI.mean()) ** 2).sum()
    r2 = 1.0 - ss_res / max(ss_tot, 1e-12)
    return float(alpha), float(beta), float(r2)


def bootstrap_inverse(c: np.ndarray, I_ref: np.ndarray,
                      I_query: np.ndarray,
                      n_boot: int = N_BOOT,
                      rng: np.random.Generator = RNG) -> dict:
    """For each query intensity, return median and 95% CI of the bootstrap
    distribution of inverse-predicted concentrations."""
    mask = (c > 0) & (I_ref > 0)
    c_v = c[mask]; I_v = I_ref[mask]
    n = len(c_v)
    log_Iq = np.log10(np.maximum(I_query, 1e-3))

    boot_chat = np.zeros((n_boot, len(I_query)))
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        beta_b, alpha_b = np.polyfit(np.log10(c_v[idx]), np.log10(I_v[idx]), 1)
        if abs(beta_b) < 1e-6:
            boot_chat[b] = np.nan
            continue
        boot_chat[b] = 10 ** ((log_Iq - alpha_b) / beta_b)
    return {
        "median": np.nanmedian(boot_chat, axis=0),
        "lo": np.nanpercentile(boot_chat, 100 * ALPHA_CI / 2, axis=0),
        "hi": np.nanpercentile(boot_chat, 100 * (1 - ALPHA_CI / 2), axis=0),
    }


def fig_calibration(wc: pd.DataFrame, params: dict, out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    colors = {"PS": "#1f3a68", "PMMA": "#a04000", "PP": "#2a7a3a"}
    c_grid = np.logspace(-7, -1, 200)

    for polymer in ["PS", "PMMA", "PP"]:
        sub = wc[wc["polymer"] == polymer]
        ax.scatter(sub["concentration_mgmL"], sub["intensity_kcps"],
                   c=colors[polymer], s=22, alpha=0.7,
                   edgecolors="white", linewidth=0.5,
                   label=f"{polymer} (n={len(sub)})")
        a = params[polymer]["alpha"]; b = params[polymer]["beta"]
        ax.plot(c_grid, 10 ** (a + b * np.log10(c_grid)),
                c=colors[polymer], lw=1.0, alpha=0.6)

    a = params["COMBINED"]["alpha"]; b = params["COMBINED"]["beta"]
    ax.plot(c_grid, 10 ** (a + b * np.log10(c_grid)),
            c="black", lw=2.2, ls="--",
            label=f"Combined fit (beta={b:.3f}, R2={params['COMBINED']['r2']:.3f})")

    c_v = wc["concentration_mgmL"].to_numpy()
    I_v = wc["intensity_kcps"].to_numpy()
    mask = (c_v > 0) & (I_v > 0)
    c_m = c_v[mask]; I_m = I_v[mask]
    boot_grid = np.zeros((N_BOOT, len(c_grid)))
    rng = np.random.default_rng(42)
    for k in range(N_BOOT):
        idx = rng.integers(0, len(c_m), size=len(c_m))
        b_k, a_k = np.polyfit(np.log10(c_m[idx]), np.log10(I_m[idx]), 1)
        boot_grid[k] = 10 ** (a_k + b_k * np.log10(c_grid))
    lo = np.percentile(boot_grid, 2.5, axis=0)
    hi = np.percentile(boot_grid, 97.5, axis=0)
    ax.fill_between(c_grid, lo, hi, color="black", alpha=0.10,
                    label="95% bootstrap PI")

    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Reported polymer concentration (mg/mL)")
    ax.set_ylabel("DLS scattering intensity (kcps)")
    ax.set_title("Forward calibration on Wei and Chua (2026) supplementary data")
    ax.grid(alpha=0.3, which="both")
    ax.legend(fontsize=8.5, loc="upper left", framealpha=0.95)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def fig_predictions(df_pred: pd.DataFrame, out_path: Path) -> None:
    order = df_pred.sort_values("c_hat_ngmL").reset_index(drop=True)
    group_colors = {
        "PW":   "#1f77b4", "WFI":  "#17becf", "RO":   "#9edae5",
        "TAP":  "#ff7f0e", "TAPF": "#ffbb78",
        "BPCA": "#d62728", "BPCB": "#9467bd",
        "SPCA": "#8c564b", "SPCB": "#e377c2",
    }
    fig, ax = plt.subplots(figsize=(9.2, 4.6))
    yerr_lo = (order["c_hat_ngmL"] - order["c_lo_ngmL"]).clip(lower=0)
    yerr_hi = (order["c_hi_ngmL"] - order["c_hat_ngmL"]).clip(lower=0)
    colors = [group_colors.get(g, "#888") for g in order["group"]]
    ax.errorbar(range(len(order)), order["c_hat_ngmL"],
                yerr=[yerr_lo, yerr_hi], fmt="none",
                ecolor="#666", elinewidth=0.9, capsize=2, alpha=0.7)
    ax.scatter(range(len(order)), order["c_hat_ngmL"],
               c=colors, s=42, edgecolors="white", linewidth=0.6, zorder=3)
    labels = (order["group"] + order["replicate"].astype(str)).to_list()
    ax.set_xticks(range(len(order)))
    ax.set_xticklabels(labels, rotation=70, fontsize=8)
    ax.set_yscale("log")
    ax.set_ylabel("Estimated equivalent PS concentration (ng/mL)")
    ax.set_title("Per-sample inverse prediction with 95% bootstrap CI")
    ax.grid(alpha=0.3, which="both")
    handles = [plt.scatter([], [], c=v, s=42, edgecolors="white",
                           linewidth=0.6, label=k)
               for k, v in group_colors.items()]
    ax.legend(handles=handles, fontsize=8, ncol=5,
              loc="upper center", bbox_to_anchor=(0.5, -0.22))
    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def fig_boxplot(df_pred: pd.DataFrame, out_path: Path) -> None:
    group_order = ["PW", "WFI", "RO", "TAPF", "TAP",
                   "BPCA", "BPCB", "SPCA", "SPCB"]
    data = [df_pred.loc[df_pred["group"] == g, "c_hat_ngmL"].to_numpy()
            for g in group_order]
    fig, ax = plt.subplots(figsize=(8.2, 4.4))
    bp = ax.boxplot(data, tick_labels=group_order, patch_artist=True,
                    widths=0.6, medianprops=dict(color="black", lw=1.2))
    colors = ["#1f77b4", "#17becf", "#9edae5", "#ffbb78", "#ff7f0e",
              "#d62728", "#9467bd", "#8c564b", "#e377c2"]
    for box, c in zip(bp["boxes"], colors):
        box.set_facecolor(c); box.set_alpha(0.55); box.set_edgecolor("#333")
    rng = np.random.default_rng(0)
    for g, d in zip(range(1, len(group_order) + 1), data):
        ax.scatter(np.full_like(d, g) + rng.uniform(-0.10, 0.10, size=len(d)),
                   d, s=22, c="#333", alpha=0.7, zorder=3)
    ax.set_yscale("log")
    ax.set_ylabel("Estimated equivalent PS concentration (ng/mL)")
    ax.set_title("Per-group inverse predictions (median +- IQR)")
    ax.grid(alpha=0.3, axis="y", which="both")
    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description="Inverse-prediction calibration")
    ap.add_argument("--wei_chua_csv",
                    default="data/external/wei_chua_processed.csv")
    ap.add_argument("--engineered_csv",
                    default="data/processed/dls_engineered.csv")
    ap.add_argument("--fig_dir", default="figures")
    ap.add_argument("--out_csv", default="inverse_predictions.csv")
    ap.add_argument("--out_json", default="inverse_calibration_params.json")
    args = ap.parse_args()

    wc = pd.read_csv(args.wei_chua_csv)
    wc = wc[(wc["concentration_mgmL"] > 0)
            & (wc["intensity_kcps"] > 0)].copy()
    print(f"Wei and Chua valid rows: {len(wc)}")

    params = {}
    for polymer in ["PS", "PMMA", "PP"]:
        sub = wc[wc["polymer"] == polymer]
        a, b, r2 = fit_loglog(sub["concentration_mgmL"].to_numpy(),
                              sub["intensity_kcps"].to_numpy())
        params[polymer] = {"alpha": a, "beta": b, "r2": r2,
                           "n": int(len(sub))}
        print(f"  {polymer:6s}: alpha={a:+.3f}  beta={b:+.3f}  R^2={r2:.3f}  n={len(sub)}")
    a, b, r2 = fit_loglog(wc["concentration_mgmL"].to_numpy(),
                          wc["intensity_kcps"].to_numpy())
    params["COMBINED"] = {"alpha": a, "beta": b, "r2": r2,
                          "n": int(len(wc))}
    print(f"  COMBINED: alpha={a:+.3f}  beta={b:+.3f}  R^2={r2:.3f}  n={len(wc)}")

    real = pd.read_csv(args.engineered_csv)
    real = real[~real["file"].str.startswith("C1_")].reset_index(drop=True)
    I_query = real["mean_intensity_kcps"].astype(float).to_numpy()
    inv = bootstrap_inverse(wc["concentration_mgmL"].to_numpy(),
                            wc["intensity_kcps"].to_numpy(), I_query)

    df_pred = pd.DataFrame({
        "file":            real["file"],
        "group":           real["group"],
        "replicate":       real["replicate"],
        "intensity_kcps":  I_query,
        "c_hat_mgmL":      inv["median"],
        "c_lo_mgmL":       inv["lo"],
        "c_hi_mgmL":       inv["hi"],
    })
    df_pred["c_hat_ngmL"] = df_pred["c_hat_mgmL"] * 1e6
    df_pred["c_lo_ngmL"]  = df_pred["c_lo_mgmL"] * 1e6
    df_pred["c_hi_ngmL"]  = df_pred["c_hi_mgmL"] * 1e6

    summary = df_pred.groupby("group").agg(
        n=("c_hat_ngmL", "size"),
        median_ngmL=("c_hat_ngmL", "median"),
        iqr_lo_ngmL=("c_hat_ngmL", lambda s: np.percentile(s, 25)),
        iqr_hi_ngmL=("c_hat_ngmL", lambda s: np.percentile(s, 75)),
    ).round(2)
    print("\nPer-group inverse predictions (ng/mL):")
    print(summary)

    fig_dir = Path(args.fig_dir)
    fig_dir.mkdir(parents=True, exist_ok=True)
    fig_calibration(wc, params, fig_dir / "inverse_calibration.png")
    fig_predictions(df_pred, fig_dir / "inverse_predictions.png")
    fig_boxplot(df_pred, fig_dir / "inverse_boxplot.png")

    df_pred.to_csv(args.out_csv, index=False)
    Path(args.out_json).write_text(json.dumps(params, indent=2, default=float))
    print(f"\nWrote {args.out_csv} and {args.out_json}")
    print(f"Figures in {fig_dir}")


if __name__ == "__main__":
    main()
