"""Train and save the two deployed model bundles.

    model_moe_primary.joblib   Mixture-of-experts trained on the real cohort
                               only, with all 62 features including mean
                               scattering intensity. Used for routine
                               screening. Expected five-fold CV accuracy on
                               the intensity-tertile task: 0.827.

    model_moe_shape.joblib     Mixture-of-experts trained on the 450 synthetic
                               samples only, with mean scattering intensity
                               masked to zero on both training and inference.
                               Reaches 0.926 on the full real cohort in the
                               intensity-masked transfer test reported in
                               Section 3.2 of the paper.

Both bundles include the fitted pipeline object, the class names and a
one-line description of the training task, so predictions can be
reproduced without retraining.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from .features import spectrum_features
from .moe import MoEDLSClassifier, ExpertSpec, CLASS_NAMES
from .moe import BAND_FEATURES, SHAPE_FEATURES


SCALAR_NO_INTENSITY = ["hydrodynamic_diameter_nm", "polydispersity_pct",
                       "d_stokes_einstein_nm", "intercept_g1sq", "fit_error",
                       "peak1_intensity_nm", "peak1_stddev_nm"]
SHAPE_ONLY_EXPERTS = [
    ExpertSpec("scalars_no_intensity", SCALAR_NO_INTENSITY, "rf"),
    ExpertSpec("bands", BAND_FEATURES, "xgb"),
    ExpertSpec("shape", SHAPE_FEATURES, "lgb"),
]


def load_real(engineered_csv: str) -> tuple[pd.DataFrame, np.ndarray]:
    """Load the engineered feature CSV, drop the C1 calibration check,
    return the DataFrame and the intensity-tertile labels."""
    df = pd.read_csv(engineered_csv)
    df = df[~df["file"].str.startswith("C1_")].reset_index(drop=True)
    q33, q67 = df["mean_intensity_kcps"].quantile([1/3, 2/3])
    y = pd.cut(df["mean_intensity_kcps"],
               bins=[-np.inf, q33, q67, np.inf],
               labels=[0, 1, 2]).astype(int).to_numpy()
    return df, y


def synthetic_dataframe(synth_npz: str) -> pd.DataFrame:
    """Featurise the synthetic samples so they can be concatenated with
    the engineered real cohort. Returns a DataFrame with the same
    engineered-feature columns as the real cohort plus a class column y."""
    s = np.load(synth_npz)
    grid = s["diameter_nm"]
    rows = []
    for i in range(len(s["target_class"])):
        dist = s["intensity_weighted"][i]
        feats = spectrum_features(grid, dist, "int")
        feats.update(spectrum_features(grid, dist, "vol"))
        feats.update(spectrum_features(grid, dist, "num"))
        feats["mean_intensity_kcps"] = float(s["mean_intensity_kcps"][i])
        feats["hydrodynamic_diameter_nm"] = float(s["cumulants_diameter_nm"][i])
        feats["polydispersity_pct"] = float(s["cumulants_pdi_pct"][i])
        feats["d_stokes_einstein_nm"] = float(s["cumulants_diameter_nm"][i])
        feats["intercept_g1sq"] = 0.95
        feats["fit_error"] = 1e-3
        pdi = float(s["cumulants_pdi_pct"][i])
        feats["peak1_area_pct"] = 100.0 if pdi < 50 else 50.0
        feats["cumulants_unreliable"] = int(pdi > 100)
        feats["y"] = int(s["target_class"][i])
        rows.append(feats)
    return pd.DataFrame(rows)


def train(engineered_csv: str, synth_npz: str, out_dir: str) -> None:
    real_df, y_real = load_real(engineered_csv)
    synth_df = synthetic_dataframe(synth_npz)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)

    print("Training MoE-FULL on real cohort ...")
    primary = MoEDLSClassifier(seed=42, gate_epochs=600,
                               gate_on_synthetic=False, verbose=False)
    primary.fit(real_df, y_real)
    joblib.dump({
        "model": primary,
        "class_names": CLASS_NAMES,
        "task": ("MoE-FULL (Cumulants + bands + shape) on the real cohort, "
                 "intensity-tertile labels."),
        "expected_cv_accuracy": 0.827,
        "training_n": int(len(real_df)),
    }, out / "model_moe_primary.joblib")
    print(f"  saved -> {out / 'model_moe_primary.joblib'}")

    print("Training MoE-SHAPE on synthetic cohort with intensity masked ...")
    real_noint = real_df.copy(); real_noint["mean_intensity_kcps"] = 0.0
    synth_noint = synth_df.copy(); synth_noint["mean_intensity_kcps"] = 0.0
    shape = MoEDLSClassifier(experts=SHAPE_ONLY_EXPERTS, seed=42,
                             gate_epochs=600, gate_on_synthetic=False,
                             verbose=False)
    shape.fit(synth_noint, synth_noint["y"].to_numpy())
    joblib.dump({
        "model": shape,
        "class_names": CLASS_NAMES,
        "task": ("MoE-SHAPE (no intensity) trained on the 450 synthetic samples. "
                 "Primary evaluation of Section 3.2; 0.926 on the real cohort."),
        "expected_transfer_accuracy": 0.926,
        "training_n": int(len(synth_noint)),
    }, out / "model_moe_shape.joblib")
    print(f"  saved -> {out / 'model_moe_shape.joblib'}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Train deployed MoE model bundles")
    ap.add_argument("--engineered_csv",
                    default="data/processed/dls_engineered.csv")
    ap.add_argument("--synth_npz",
                    default="data/synthetic/synthetic_augmented.npz")
    ap.add_argument("--out_dir", default="models")
    args = ap.parse_args()
    train(args.engineered_csv, args.synth_npz, args.out_dir)


if __name__ == "__main__":
    main()
