"""Extract Cumulants scalars and the 142-bin intensity-weighted size
distribution from DynaPro NanoStar XLSX exports.

The workbook layout is:

    Column A, B      parameter labels
    Column C         scalar values at fixed rows
    Column E         empty separator
    Column F         particle diameter axis in nm (142 log-spaced bins)
    Column G         intensity-weighted size distribution (%)
    Column H         volume-weighted size distribution (%)
    Column I         number-weighted size distribution (%)
    Columns J K L    cumulative undersize distributions

Data rows run from row 9 to row 150 (openpyxl indices 8 to 149).
"""
from __future__ import annotations

import argparse
import csv
import glob
import os
import re
from pathlib import Path

import numpy as np
import openpyxl

SCALAR_ROWS = {
    "hydrodynamic_diameter_nm": (7, 3),
    "polydispersity_pct":       (8, 3),
    "intercept_g1sq":           (9, 3),
    "baseline":                 (10, 3),
    "mean_intensity_kcps":      (11, 3),
    "absolute_intensity_kcps":  (12, 3),
    "fit_error":                (13, 3),
    "diffusion_coef_um2_s":     (14, 3),
    "peak1_intensity_nm":       (24, 3),
    "peak1_area_pct":           (25, 3),
    "peak1_stddev_nm":          (26, 3),
    "peak2_intensity_nm":       (27, 3),
    "peak2_area_pct":           (28, 3),
}

GROUP_FULL_NAME = {
    "PW":   "Milli-Q ultrapure water",
    "RO":   "Reverse-osmosis filtered water",
    "WFI":  "Water for injection",
    "TAP":  "Tap water, unfiltered",
    "TAPF": "Tap water, 0.22 um syringe filtered",
    "BPCA": "Bottled water, brand A",
    "BPCB": "Bottled water, brand B",
    "SPCA": "Heat-stressed control, brand A",
    "SPCB": "Heat-stressed control, brand B",
    "C1":   "Instrument calibration check",
}

DIST_COLUMNS = {
    "intensity_weighted": 6,
    "volume_weighted":    7,
    "number_weighted":    8,
    "undersize_intensity": 9,
    "undersize_volume":   10,
    "undersize_number":   11,
}


def parse_group(filename: str) -> tuple[str, int]:
    """Split a filename like 'BPCA2_2026-05-13-...' into ('BPCA', 2)."""
    match = re.match(r"([A-Z]+)(\d+)_", os.path.basename(filename))
    return (match.group(1), int(match.group(2))) if match else ("?", 0)


def read_one(path: str) -> dict:
    """Read one XLSX file, returning scalars and distribution vectors."""
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]

    header_cache = []
    diameter_nm = []
    dists = {k: [] for k in DIST_COLUMNS}

    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i < 30:
            header_cache.append(row)
        if i >= 8:
            v = row[5] if len(row) > 5 else None
            if not isinstance(v, (int, float)):
                if diameter_nm:
                    break
                else:
                    continue
            diameter_nm.append(float(v))
            for k, c in DIST_COLUMNS.items():
                cv = row[c] if len(row) > c else None
                dists[k].append(float(cv) if isinstance(cv, (int, float)) else 0.0)
    wb.close()

    scalars = {}
    for key, (r, c) in SCALAR_ROWS.items():
        v = None
        if r - 1 < len(header_cache) and c - 1 < len(header_cache[r - 1]):
            v = header_cache[r - 1][c - 1]
        scalars[key] = v

    grp, rep = parse_group(path)
    return {
        "file": os.path.basename(path),
        "group": grp,
        "group_desc": GROUP_FULL_NAME.get(grp, "?"),
        "replicate": rep,
        "diameter_nm": np.array(diameter_nm, dtype=float),
        **{k: np.array(v, dtype=float) for k, v in dists.items()},
        **scalars,
    }


def extract_all(src_dir: str, out_dir: str) -> int:
    """Extract every XLSX in src_dir, write dls_features.csv and
    size_distributions.npz to out_dir. Returns the number of files processed.
    """
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)

    records = []
    diameters, intensity_dist, volume_dist, number_dist = [], [], [], []
    undersize_int, undersize_vol, undersize_num = [], [], []

    for f in sorted(glob.glob(os.path.join(src_dir, "*.xlsx"))):
        rec = read_one(f)
        diameters.append(rec["diameter_nm"])
        intensity_dist.append(rec["intensity_weighted"])
        volume_dist.append(rec["volume_weighted"])
        number_dist.append(rec["number_weighted"])
        undersize_int.append(rec["undersize_intensity"])
        undersize_vol.append(rec["undersize_volume"])
        undersize_num.append(rec["undersize_number"])
        scalar_row = {k: rec[k] for k in ["file", "group", "group_desc", "replicate",
                                          *SCALAR_ROWS.keys()]}
        records.append(scalar_row)

    lengths = {len(d) for d in diameters}
    if len(lengths) != 1:
        raise ValueError(f"Diameter grids differ across files: {lengths}")
    diameter_nm = diameters[0]

    np.savez(
        out_dir_p / "size_distributions.npz",
        diameter_nm=diameter_nm,
        intensity_weighted=np.array(intensity_dist),
        volume_weighted=np.array(volume_dist),
        number_weighted=np.array(number_dist),
        undersize_intensity=np.array(undersize_int),
        undersize_volume=np.array(undersize_vol),
        undersize_number=np.array(undersize_num),
        files=np.array([r["file"] for r in records]),
        groups=np.array([r["group"] for r in records]),
    )

    cols = ["file", "group", "group_desc", "replicate", *SCALAR_ROWS.keys()]
    with open(out_dir_p / "dls_features.csv", "w", newline="", encoding="utf-8") as g:
        writer = csv.DictWriter(g, fieldnames=cols)
        writer.writeheader()
        for r in records:
            writer.writerow(r)
    return len(records)


def main() -> None:
    ap = argparse.ArgumentParser(description="Extract DLS features from DynaPro NanoStar XLSX exports")
    ap.add_argument("src_dir", help="Directory containing raw XLSX files")
    ap.add_argument("-o", "--out_dir", default="data/processed", help="Output directory")
    args = ap.parse_args()
    n = extract_all(args.src_dir, args.out_dir)
    print(f"Extracted scalars and 142-bin distributions for {n} measurements to {args.out_dir}")


if __name__ == "__main__":
    main()
