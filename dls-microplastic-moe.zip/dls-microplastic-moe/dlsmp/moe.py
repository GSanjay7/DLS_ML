"""Mixture-of-experts classifier for DLS-based contamination screening.

Reference for the mixture-of-experts formulation:
    Jacobs, R.A., Jordan, M.I., Nowlan, S.J. and Hinton, G.E. (1991).
    Adaptive mixtures of local experts. Neural Computation, 3(1), 79-87.

Three experts operate on complementary feature subsets and a gating
network conditioned on Cumulants fit-quality indicators combines them.
The combined class log-probability is

    log P(y | x) = logsumexp_i [ log g_i(x) + log P_i(y | x_i) ]

where g_i(x) is the gating weight for expert i and P_i(y | x_i) is
expert i's class probability. Soft routing is used throughout, so the
model remains differentiable end to end.

Expert specifications:
    E1 Scalars   Random forest on the Cumulants triplet, Stokes-Einstein
                 cross-check and fit-quality scalars. Best when the
                 Cumulants fit converges.
    E2 Bands     XGBoost on the size-band integrated intensities. Robust
                 to Cumulants fit failure because it integrates the full
                 distribution into a small number of numbers.
    E3 Shape     LightGBM on distribution moments and percentiles.
                 Captures multi-modality and skewness directly.

Training runs in two stages: experts are fitted on the union of the real
cohort and CORAL-adapted synthetic samples with a 1.0 / 0.5 sample-weight
split, then the gating network is fitted on the real cohort using a
weighted focal cross-entropy loss. Class weights are inverse-frequency.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

CLASS_NAMES = ["Low", "Medium", "High"]

SCALAR_FEATURES = ["mean_intensity_kcps", "hydrodynamic_diameter_nm",
                   "polydispersity_pct", "d_stokes_einstein_nm",
                   "intercept_g1sq", "fit_error"]
BAND_FEATURES = ["int_frac_sub_10nm", "int_frac_10_100nm",
                 "int_frac_100_1000nm", "int_frac_1_10um",
                 "vol_frac_10_100nm", "vol_frac_100_1000nm"]
SHAPE_FEATURES = ["int_log10d_mean", "int_log10d_std", "int_log10d_skew",
                  "int_log10d_kurt", "int_D10", "int_D50", "int_D90",
                  "int_n_modes", "int_entropy"]
GATE_FEATURES = ["intercept_g1sq", "fit_error", "polydispersity_pct",
                 "peak1_area_pct", "cumulants_unreliable"]


@dataclass
class ExpertSpec:
    name: str
    feats: list[str]
    learner: str      # "rf" | "xgb" | "lgb"


DEFAULT_EXPERTS = [
    ExpertSpec("scalars", SCALAR_FEATURES, "rf"),
    ExpertSpec("bands",   BAND_FEATURES,   "xgb"),
    ExpertSpec("shape",   SHAPE_FEATURES,  "lgb"),
]


class GatingMLP(nn.Module):
    """Two hidden layer MLP with GELU activation and dropout, returning
    a log-softmax over the expert index."""

    def __init__(self, n_in: int, n_experts: int, hidden: int = 32):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(n_in, hidden),
            nn.GELU(),
            nn.Dropout(0.20),
            nn.Linear(hidden, hidden),
            nn.GELU(),
            nn.Dropout(0.10),
            nn.Linear(hidden, n_experts),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.log_softmax(self.fc(x), dim=-1)


class MoEDLSClassifier(BaseEstimator, ClassifierMixin):
    """Mixture-of-experts classifier over feature-subset experts."""

    def __init__(self, experts: list[ExpertSpec] | None = None,
                 gate_hidden: int = 32, gate_epochs: int = 400,
                 gate_lr: float = 1e-3, focal_gamma: float = 2.0,
                 seed: int = 42, verbose: bool = False,
                 gate_on_synthetic: bool = True,
                 synthetic_sample_weight: float = 0.5):
        self.experts = experts or DEFAULT_EXPERTS
        self.gate_hidden = gate_hidden
        self.gate_epochs = gate_epochs
        self.gate_lr = gate_lr
        self.focal_gamma = focal_gamma
        self.seed = seed
        self.verbose = verbose
        self.gate_on_synthetic = gate_on_synthetic
        self.synthetic_sample_weight = synthetic_sample_weight

    def _make_learner(self, kind: str):
        if kind == "rf":
            return RandomForestClassifier(n_estimators=400, class_weight="balanced",
                                          random_state=self.seed, n_jobs=-1)
        if kind == "xgb":
            return XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.07,
                                 subsample=0.9, colsample_bytree=0.9,
                                 objective="multi:softprob", num_class=3,
                                 random_state=self.seed, n_jobs=-1,
                                 eval_metric="mlogloss")
        if kind == "lgb":
            return LGBMClassifier(n_estimators=300, learning_rate=0.07,
                                  num_leaves=15, random_state=self.seed,
                                  n_jobs=-1, verbose=-1)
        raise ValueError(kind)

    def _safe_X(self, X_df: pd.DataFrame, feats: list[str]) -> np.ndarray:
        X = X_df.reindex(columns=feats).apply(pd.to_numeric, errors="coerce")
        X = X.fillna(X.median(numeric_only=True)).fillna(0.0)
        return X.to_numpy(dtype=np.float32)

    def fit(self, X_df: pd.DataFrame, y: np.ndarray,
            X_syn: pd.DataFrame | None = None,
            y_syn: np.ndarray | None = None,
            sample_weight: np.ndarray | None = None):
        self.classes_ = np.array([0, 1, 2])
        self.expert_models_ = []
        self.expert_scalers_ = []

        for spec in self.experts:
            X_real = self._safe_X(X_df, spec.feats)
            scaler = StandardScaler().fit(X_real)
            X_real_s = scaler.transform(X_real)

            if X_syn is not None and y_syn is not None:
                from .domain_adapt import coral_align
                X_syn_arr = self._safe_X(X_syn, spec.feats)
                X_syn_s = scaler.transform(X_syn_arr)
                try:
                    X_syn_adapted = coral_align(X_syn_s, X_real_s, eps=1e-2)
                except Exception:
                    X_syn_adapted = X_syn_s
                X_fit = np.vstack([X_real_s, X_syn_adapted])
                y_fit = np.concatenate([y, y_syn])
                sw_real = (sample_weight if sample_weight is not None
                           else np.ones(len(y)))
                sw = np.concatenate([sw_real,
                                     self.synthetic_sample_weight
                                     * np.ones(len(y_syn))])
            else:
                X_fit, y_fit = X_real_s, y
                sw = sample_weight

            learner = self._make_learner(spec.learner)
            fit_kwargs = {"sample_weight": sw} if sw is not None else {}
            learner.fit(X_fit, y_fit, **fit_kwargs)
            self.expert_models_.append(learner)
            self.expert_scalers_.append(scaler)

        # Gating stage.
        torch.manual_seed(self.seed)
        if (self.gate_on_synthetic and X_syn is not None
                and y_syn is not None):
            X_gate_df = pd.concat([X_df.reset_index(drop=True),
                                   X_syn.reset_index(drop=True)],
                                  ignore_index=True)
            y_gate = np.concatenate([y, y_syn])
            sw_gate = np.concatenate([np.ones(len(y)),
                                      self.synthetic_sample_weight
                                      * np.ones(len(y_syn))])
        else:
            X_gate_df = X_df
            y_gate = y
            sw_gate = np.ones(len(y))

        X_real_gate = self._safe_X(X_gate_df, GATE_FEATURES)
        self.gate_scaler_ = StandardScaler().fit(X_real_gate)
        Xg = self.gate_scaler_.transform(X_real_gate)
        Xg_t = torch.tensor(Xg, dtype=torch.float32)

        expert_log_probs = []
        for spec, learner, scaler in zip(self.experts,
                                         self.expert_models_,
                                         self.expert_scalers_):
            X = scaler.transform(self._safe_X(X_gate_df, spec.feats))
            p = np.clip(learner.predict_proba(X), 1e-9, 1 - 1e-9)
            expert_log_probs.append(np.log(p))
        elp = np.stack(expert_log_probs, axis=0)
        elp_t = torch.tensor(elp, dtype=torch.float32)
        y_t = torch.tensor(y_gate, dtype=torch.long)
        sw_gate_t = torch.tensor(sw_gate, dtype=torch.float32)

        counts = np.bincount(y_gate, minlength=3).astype(float)
        alpha = torch.tensor(counts.sum() / (3 * np.maximum(counts, 1)),
                             dtype=torch.float32)

        self.gating_ = GatingMLP(n_in=len(GATE_FEATURES),
                                 n_experts=len(self.experts),
                                 hidden=self.gate_hidden)
        opt = torch.optim.Adam(self.gating_.parameters(),
                               lr=self.gate_lr, weight_decay=1e-4)
        for epoch in range(self.gate_epochs):
            self.gating_.train(True)
            opt.zero_grad()
            log_g = self.gating_(Xg_t)
            combined = torch.logsumexp(
                log_g.transpose(0, 1).unsqueeze(-1) + elp_t, dim=0)
            log_p = F.log_softmax(combined, dim=-1)
            target_lp = log_p.gather(1, y_t.view(-1, 1)).squeeze(1)
            target_p = target_lp.exp()
            focal_w = (1.0 - target_p) ** self.focal_gamma
            per_sample = -focal_w * target_lp * alpha[y_t]
            loss = (per_sample * sw_gate_t).sum() / sw_gate_t.sum()
            loss.backward()
            opt.step()
            if self.verbose and epoch % 100 == 0:
                with torch.no_grad():
                    acc = (log_p.argmax(1) == y_t).float().mean().item()
                print(f"  gate epoch {epoch:4d}  loss={loss.item():.4f}  acc={acc:.3f}")

        self.fitted_ = True
        return self

    def predict_proba(self, X_df: pd.DataFrame) -> np.ndarray:
        self.gating_.train(False)
        Xg = self.gate_scaler_.transform(self._safe_X(X_df, GATE_FEATURES))
        with torch.no_grad():
            log_g = self.gating_(torch.tensor(Xg, dtype=torch.float32)).numpy()
        log_probs = []
        for spec, learner, scaler in zip(self.experts,
                                         self.expert_models_,
                                         self.expert_scalers_):
            X = scaler.transform(self._safe_X(X_df, spec.feats))
            p = np.clip(learner.predict_proba(X), 1e-9, 1 - 1e-9)
            log_probs.append(np.log(p))
        elp = np.stack(log_probs, axis=0)
        log_g_e = log_g.T[:, :, None]
        combined = np.log(np.exp(log_g_e + elp).sum(axis=0))
        combined -= combined.max(axis=1, keepdims=True)
        p_out = np.exp(combined)
        p_out /= p_out.sum(axis=1, keepdims=True)
        return p_out

    def predict(self, X_df: pd.DataFrame) -> np.ndarray:
        return self.predict_proba(X_df).argmax(axis=1)

    def expert_predict_proba(self, X_df: pd.DataFrame) -> dict:
        out = {}
        for spec, learner, scaler in zip(self.experts,
                                         self.expert_models_,
                                         self.expert_scalers_):
            X = scaler.transform(self._safe_X(X_df, spec.feats))
            out[spec.name] = learner.predict_proba(X)
        return out

    def expert_gates(self, X_df: pd.DataFrame) -> np.ndarray:
        self.gating_.train(False)
        Xg = self.gate_scaler_.transform(self._safe_X(X_df, GATE_FEATURES))
        with torch.no_grad():
            log_g = self.gating_(torch.tensor(Xg, dtype=torch.float32)).numpy()
        return np.exp(log_g)
