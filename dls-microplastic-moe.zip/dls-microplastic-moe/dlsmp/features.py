"""Engineered features from DLS size distributions.

Given the 142-bin intensity-, volume- and number-weighted distributions and
the Cumulants scalars produced by extract_features, this module computes:

  Distribution shape on log10(d) for each weighting
    - first four moments
    - 10th, 50th, 90th percentile diameters
    - number of modes (Savitzky-Golay-smoothed peak finder)
    - Shannon entropy (log2) of the normalised distribution
    - L2 norm of the unnormalised intensity vector

  Size-band integrated intensity for each weighting
    - fraction in 0-10 nm, 10-100 nm, 100-1000 nm, 1-10 um bands

  Stokes-Einstein cross-check
    - d_SE = kT / (3 pi eta D) from the reported diffusion coefficient
    - residual (d_SE - d_Cumulants) as a fit-quality diagnostic
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import signal, stats

K_B = 1.380649e-23        # J/K
T_K = 298.15              # K
ETA_WATER = 0.890e-3      # Pa s at 25 C


def stokes_einstein_diameter_nm(diffusion_um2_s: float) -> float:
    """Compute the Stokes-Einstein hydrodynamic diameter in nm from the
    translational diffusion coefficient in um^2/s."""
    if diffusion_um2_s is None or diffusion_um2_s <= 0:
        return np.nan
    D_si = diffusion_um2_s * 1e-12
    d_m = K_B * T_K / (3 * np.pi * ETA_WATER * D_si)
    return d_m * 1e9


def _weighted_percentile(x: np.ndarray, w: np.ndarray, q: float) -> float:
    if w.sum() <= 0:
        return np.nan
    order = np.argsort(x)
    xs, ws = x[order], w[order]
    cdf = np.cumsum(ws) / ws.sum()
    idx = min(np.searchsorted(cdf, q / 100.0), len(xs) - 1)
    return float(xs[idx])


def spectrum_features(d_nm: np.ndarray, w_pct: np.ndarray, tag: str) -> dict:
    """Compute the fourteen distribution-shape and size-band features from
    one weighted distribution.

    Parameters
    ----------
    d_nm : ndarray
        142 log-spaced diameter bins in nm.
    w_pct : ndarray
        Weighted distribution values in %; may contain negatives from
        numerical fitting and is clipped to zero here.
    tag : str
        Prefix for the output keys, e.g. 'int', 'vol' or 'num'.
    """
    w = np.maximum(w_pct, 0.0)
    if w.sum() <= 1e-9:
        keys = ["log10d_mean", "log10d_std", "log10d_skew", "log10d_kurt",
                "D10", "D50", "D90", "n_modes", "entropy", "l2",
                "frac_sub_10nm", "frac_10_100nm", "frac_100_1000nm", "frac_1_10um"]
        default = lambda k: (0.0 if any(s in k for s in ("n_modes", "frac_", "l2"))
                              else np.nan)
        return {f"{tag}_{k}": default(k) for k in keys}

    p = w / w.sum()
    log_d = np.log10(np.maximum(d_nm, 1e-6))
    mean = float((p * log_d).sum())
    var = float((p * (log_d - mean) ** 2).sum())
    std = float(np.sqrt(var))
    if std > 0:
        skew = float((p * ((log_d - mean) / std) ** 3).sum())
        kurt = float((p * ((log_d - mean) / std) ** 4).sum() - 3.0)
    else:
        skew, kurt = 0.0, 0.0

    if len(w) >= 11:
        smoothed = signal.savgol_filter(w, window_length=11, polyorder=3)
    else:
        smoothed = w
    prominence = max(w) * 0.05 if w.max() > 0 else 1e-6
    peaks, _ = signal.find_peaks(smoothed, prominence=prominence)

    out = {
        f"{tag}_log10d_mean": mean,
        f"{tag}_log10d_std":  std,
        f"{tag}_log10d_skew": skew,
        f"{tag}_log10d_kurt": kurt,
        f"{tag}_D10": _weighted_percentile(d_nm, w, 10),
        f"{tag}_D50": _weighted_percentile(d_nm, w, 50),
        f"{tag}_D90": _weighted_percentile(d_nm, w, 90),
        f"{tag}_n_modes": int(len(peaks)),
        f"{tag}_entropy": float(stats.entropy(p + 1e-12, base=2)),
        f"{tag}_l2": float(np.linalg.norm(w)),
    }

    bands = [(0, 10, "sub_10nm"), (10, 100, "10_100nm"),
             (100, 1000, "100_1000nm"), (1000, 10000, "1_10um")]
    for lo, hi, name in bands:
        mask = (d_nm >= lo) & (d_nm < hi)
        out[f"{tag}_frac_{name}"] = float(w[mask].sum() / w.sum())
    return out


def engineer_all(scalars_csv: str, distributions_npz: str) -> pd.DataFrame:
    """Combine Cumulants scalars with engineered distribution features.
    Returns a DataFrame with one row per measurement.
    """
    df = pd.read_csv(scalars_csv)
    arr = np.load(distributions_npz)
    d_nm = arr["diameter_nm"]
    files = arr["files"]
    file_to_row = {f: i for i, f in enumerate(files)}

    rows = []
    for _, scal in df.iterrows():
        i = file_to_row.get(scal["file"])
        if i is None:
            continue
        rec = dict(scal)
        rec.update(spectrum_features(d_nm, arr["intensity_weighted"][i], "int"))
        rec.update(spectrum_features(d_nm, arr["volume_weighted"][i], "vol"))
        rec.update(spectrum_features(d_nm, arr["number_weighted"][i], "num"))
        rec["d_stokes_einstein_nm"] = stokes_einstein_diameter_nm(
            scal.get("diffusion_coef_um2_s"))
        if pd.notna(rec.get("hydrodynamic_diameter_nm")):
            rec["d_se_minus_cumulants_nm"] = (
                rec["d_stokes_einstein_nm"] - rec["hydrodynamic_diameter_nm"])
        else:
            rec["d_se_minus_cumulants_nm"] = np.nan
        rec["cumulants_unreliable"] = int((scal.get("polydispersity_pct") or 0) > 100)
        rows.append(rec)
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser(description="Engineer features from DLS distributions")
    ap.add_argument("scalars_csv", help="Path to dls_features.csv from extract_features")
    ap.add_argument("distributions_npz", help="Path to size_distributions.npz")
    ap.add_argument("-o", "--out_csv", default="data/processed/dls_engineered.csv",
                    help="Output CSV path")
    args = ap.parse_args()

    df = engineer_all(args.scalars_csv, args.distributions_npz)
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out_csv, index=False)
    print(f"Engineered {len(df)} rows x {df.shape[1]} columns -> {args.out_csv}")


if __name__ == "__main__":
    main()
