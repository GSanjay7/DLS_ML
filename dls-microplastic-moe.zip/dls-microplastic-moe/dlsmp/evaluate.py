"""Reproduce the benchmark table (Table 4) of the paper.

Runs five configurations:

    B1  MoE-FULL, real only                     five-fold CV on the real cohort
    B2  MoE-FULL, real + synthetic, mixed CV    ablation
    B3  MoE-SHAPE, real only                    no intensity, ablation
    B4  Compact RF, 16 features, no intensity   small-model ablation
    B5  Synthetic-to-real transfer, shape only  primary evaluation

Writes a JSON metrics file at the repository root.
"""
from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from .moe import MoEDLSClassifier, CLASS_NAMES
from .train import (SHAPE_ONLY_EXPERTS, load_real, synthetic_dataframe)

warnings.filterwarnings("ignore")

COMPACT_RF_FEATURES = [
    "hydrodynamic_diameter_nm", "polydispersity_pct", "intercept_g1sq",
    "fit_error", "d_stokes_einstein_nm", "d_se_minus_cumulants_nm",
    "int_log10d_mean", "int_log10d_std", "int_log10d_skew", "int_D50",
    "int_n_modes", "int_entropy",
    "int_frac_sub_10nm", "int_frac_10_100nm",
    "int_frac_100_1000nm", "int_frac_1_10um",
]


def cv_score(make_model, X_df, y, X_syn=None, y_syn=None,
             n_splits: int = 5, seed: int = 42) -> dict:
    """Five-fold stratified CV. When X_syn is passed, the synthetic samples
    are added to every training fold (and to the gating training set)."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    accs, f1s, cms = [], [], np.zeros((3, 3), dtype=int)
    for tr, te in skf.split(X_df, y):
        m = make_model()
        if X_syn is not None:
            m.fit(X_df.iloc[tr], y[tr], X_syn=X_syn, y_syn=y_syn)
        else:
            m.fit(X_df.iloc[tr], y[tr])
        p = m.predict(X_df.iloc[te])
        accs.append(accuracy_score(y[te], p))
        f1s.append(f1_score(y[te], p, average="macro"))
        cms += confusion_matrix(y[te], p, labels=[0, 1, 2])
    return {"acc_mean": float(np.mean(accs)),
            "acc_std": float(np.std(accs)),
            "f1_mean": float(np.mean(f1s)),
            "cm": cms.tolist()}


def synthetic_to_real_transfer(X_syn, y_syn, X_tgt, y_tgt,
                               experts=None) -> dict:
    """Train the MoE on synthetic samples only, test on the real cohort."""
    m = MoEDLSClassifier(experts=experts, seed=42,
                         gate_epochs=400, gate_on_synthetic=False)
    m.fit(X_syn, y_syn)
    p = m.predict(X_tgt)
    return {"acc": float(accuracy_score(y_tgt, p)),
            "f1": float(f1_score(y_tgt, p, average="macro")),
            "cm": confusion_matrix(y_tgt, p, labels=[0, 1, 2]).tolist()}


def compact_rf_cv(X_df: pd.DataFrame, y: np.ndarray) -> dict:
    """The single-random-forest ablation from Appendix D."""
    X = X_df[COMPACT_RF_FEATURES].apply(pd.to_numeric, errors="coerce")
    X = X.fillna(X.median(numeric_only=True)).fillna(0.0)
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    accs, f1s = [], []
    for tr, te in skf.split(X, y):
        clf = Pipeline([
            ("scaler", StandardScaler()),
            ("rf", RandomForestClassifier(n_estimators=400,
                                          class_weight="balanced",
                                          random_state=42, n_jobs=-1)),
        ])
        clf.fit(X.iloc[tr], y[tr])
        p = clf.predict(X.iloc[te])
        accs.append(accuracy_score(y[te], p))
        f1s.append(f1_score(y[te], p, average="macro"))
    return {"acc_mean": float(np.mean(accs)),
            "acc_std": float(np.std(accs)),
            "f1_mean": float(np.mean(f1s))}


def main() -> None:
    ap = argparse.ArgumentParser(description="Reproduce paper Table 4")
    ap.add_argument("--engineered_csv",
                    default="data/processed/dls_engineered.csv")
    ap.add_argument("--synth_npz",
                    default="data/synthetic/synthetic_augmented.npz")
    ap.add_argument("--out_json", default="metrics.json")
    args = ap.parse_args()

    real_df, y_real = load_real(args.engineered_csv)
    synth = synthetic_dataframe(args.synth_npz)
    real_noint = real_df.copy(); real_noint["mean_intensity_kcps"] = 0.0
    synth_noint = synth.copy();   synth_noint["mean_intensity_kcps"] = 0.0

    print("\n=== Reproducing Table 4 ===\n")
    out: dict = {}

    print("[B1] MoE-FULL, real only ...")
    out["B1_moe_full_real_only"] = cv_score(
        lambda: MoEDLSClassifier(seed=42, gate_epochs=400,
                                 gate_on_synthetic=False),
        real_df, y_real)
    r = out["B1_moe_full_real_only"]
    print(f"   acc={r['acc_mean']:.3f}+/-{r['acc_std']:.3f}  F1={r['f1_mean']:.3f}")

    print("\n[B2] MoE-FULL, real + synthetic, mixed CV ...")
    out["B2_moe_full_real_plus_synthetic"] = cv_score(
        lambda: MoEDLSClassifier(seed=42, gate_epochs=400,
                                 gate_on_synthetic=True,
                                 synthetic_sample_weight=0.5),
        real_df, y_real,
        X_syn=synth, y_syn=synth["y"].to_numpy())
    r = out["B2_moe_full_real_plus_synthetic"]
    print(f"   acc={r['acc_mean']:.3f}+/-{r['acc_std']:.3f}  F1={r['f1_mean']:.3f}")

    print("\n[B3] MoE-SHAPE (no intensity), real only ...")
    out["B3_moe_shape_real_only"] = cv_score(
        lambda: MoEDLSClassifier(experts=SHAPE_ONLY_EXPERTS, seed=42,
                                 gate_epochs=400, gate_on_synthetic=False),
        real_df, y_real)
    r = out["B3_moe_shape_real_only"]
    print(f"   acc={r['acc_mean']:.3f}+/-{r['acc_std']:.3f}  F1={r['f1_mean']:.3f}")

    print("\n[B4] Compact RF, 16 features, no intensity ...")
    out["B4_compact_rf_no_intensity"] = compact_rf_cv(real_df, y_real)
    r = out["B4_compact_rf_no_intensity"]
    print(f"   acc={r['acc_mean']:.3f}+/-{r['acc_std']:.3f}  F1={r['f1_mean']:.3f}")

    print("\n[B5] Synthetic-to-real transfer, shape only, intensity masked ...")
    out["B5_transfer_shape_only"] = synthetic_to_real_transfer(
        synth_noint, synth_noint["y"].to_numpy(),
        real_noint, y_real, experts=SHAPE_ONLY_EXPERTS)
    r = out["B5_transfer_shape_only"]
    print(f"   acc={r['acc']:.3f}  F1={r['f1']:.3f}")

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(out, indent=2, default=float))
    print(f"\nMetrics -> {args.out_json}")


if __name__ == "__main__":
    main()
