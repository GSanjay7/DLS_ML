"""CORAL (Correlation Alignment) domain adaptation.

Reference:
    Sun, B., Feng, J. and Saenko, K. (2016). Return of frustratingly easy
    domain adaptation. In Proceedings of the AAAI Conference on Artificial
    Intelligence, vol. 30, pp. 2058-2065.

Given a source (synthetic) feature matrix X_s and a target (real) feature
matrix X_t, we align X_s so that its first and second moments (mean and
covariance) match those of X_t. The transform is closed-form:

    x' = (x_s - mu_s) Sigma_s^{-1/2} Sigma_t^{1/2} + mu_t

Class labels are preserved by construction. Matrix square roots are taken by
symmetric eigendecomposition with an epsilon regularisation for numerical
stability at small sample size.
"""
from __future__ import annotations

import numpy as np


def _matrix_sqrt(C: np.ndarray, eps: float = 1e-3) -> np.ndarray:
    """Symmetric PSD matrix square root, with epsilon regularisation."""
    C_reg = C + eps * np.eye(C.shape[0])
    vals, vecs = np.linalg.eigh(C_reg)
    vals = np.clip(vals, eps, None)
    return vecs @ np.diag(np.sqrt(vals)) @ vecs.T


def _matrix_inv_sqrt(C: np.ndarray, eps: float = 1e-3) -> np.ndarray:
    """Symmetric PSD inverse matrix square root."""
    C_reg = C + eps * np.eye(C.shape[0])
    vals, vecs = np.linalg.eigh(C_reg)
    vals = np.clip(vals, eps, None)
    return vecs @ np.diag(1.0 / np.sqrt(vals)) @ vecs.T


def coral_align(X_source: np.ndarray, X_target: np.ndarray,
                eps: float = 1e-3) -> np.ndarray:
    """Align source moments to target moments.

    Parameters
    ----------
    X_source : ndarray of shape (n_source, n_features)
    X_target : ndarray of shape (n_target, n_features)
    eps      : epsilon regularisation for the eigenvalue clip

    Returns
    -------
    ndarray of shape (n_source, n_features)
        Transformed X_source, whose mean and covariance now match X_target.
    """
    mu_s, mu_t = X_source.mean(axis=0), X_target.mean(axis=0)
    Xs_c = X_source - mu_s
    Xt_c = X_target - mu_t
    C_s = np.cov(Xs_c, rowvar=False, bias=True)
    C_t = np.cov(Xt_c, rowvar=False, bias=True)
    if C_s.ndim == 0:  # single-feature edge case
        scale = np.sqrt((C_t + eps) / (C_s + eps))
        return mu_t + scale * Xs_c
    W = _matrix_inv_sqrt(C_s, eps) @ _matrix_sqrt(C_t, eps)
    return Xs_c @ W + mu_t


def coral_align_per_class(X_source: np.ndarray, y_source: np.ndarray,
                          X_target: np.ndarray, y_target: np.ndarray,
                          eps: float = 1e-3) -> np.ndarray:
    """Apply CORAL separately for each class. Falls back to the raw source
    rows when a class has fewer than n_features + 2 target samples."""
    n_feats = X_source.shape[1]
    out = X_source.copy()
    classes = sorted(set(y_source.tolist()) | set(y_target.tolist()))
    for c in classes:
        src_mask = (y_source == c)
        tgt_mask = (y_target == c)
        if tgt_mask.sum() < n_feats + 2:
            continue
        out[src_mask] = coral_align(X_source[src_mask], X_target[tgt_mask], eps)
    return out
