"""Synthetic augmentation for the DLS contamination classifier.

Two complementary generators produce 450 balanced synthetic samples that
between them cover the multi-modal, high-polydispersity regime that
characterises real drinking water. The generators are described in
Section 2.8 of the paper; full pseudocode is in ESI Appendix A.

  Multi-modal lognormal mixture generator (210 samples)
    One to three lognormal components per sample, representing
    biocolloidal material (geometric mean 5 to 25 nm), plastic particulates
    (50 to 1500 nm) and aggregates (1 to 10 um), with class-conditional
    priors on component locations and amplitudes. Rayleigh intensity
    weighting (d^6) is applied when binning to the 142-bin grid.
    Multi-modal samples receive a simulated Cumulants fit failure
    (polydispersity above 100%).

  Empirical bootstrap-perturb generator (240 samples)
    Samples a real distribution of the target class, then applies
    Gaussian perturbation (sigma = 0.20 on log-amplitude per bin), a small
    bin shift, multiplicative speckle at 20 dB and a dust spike with
    probability 0.25.

The mean scattering intensity of each synthetic sample is drawn from the
class-conditional empirical distribution of the real cohort with a
+-20% multiplicative log-noise, so that intensity-tertile labels transfer
without gap.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


@dataclass
class SyntheticSample:
    name: str
    target_class: int
    diameter_nm: np.ndarray
    intensity_weighted: np.ndarray
    cumulants_diameter_nm: float
    cumulants_pdi_pct: float
    mean_intensity_kcps: float
    source: str


def _cumulants_estimate(d_nm: np.ndarray, w: np.ndarray) -> tuple[float, float]:
    """Approximate Cumulants diameter and PDI from a binned distribution."""
    if w.sum() <= 0:
        return float("nan"), float("nan")
    p = w / w.sum()
    mean = float((p * d_nm).sum())
    var = float((p * (d_nm - mean) ** 2).sum())
    pdi_pct = 100.0 * var / max(mean ** 2, 1e-9)
    return mean, pdi_pct


def _bin_lognormal(mu_nm: float, sigma_log: float, grid_nm: np.ndarray,
                   intensity_weight_power: float = 6.0,
                   n_particles: int = 20000,
                   rng: np.random.Generator | None = None) -> np.ndarray:
    """Sample a lognormal particle population, bin as intensity-weighted."""
    if rng is None:
        rng = np.random.default_rng()
    d_samples = rng.lognormal(mean=np.log(mu_nm), sigma=sigma_log, size=n_particles)
    weights = d_samples ** intensity_weight_power
    edges = np.concatenate(([grid_nm[0] * 0.9],
                            (grid_nm[1:] + grid_nm[:-1]) / 2,
                            [grid_nm[-1] * 1.1]))
    hist, _ = np.histogram(d_samples, bins=edges, weights=weights)
    if hist.sum() <= 0:
        return np.zeros_like(grid_nm)
    return 100.0 * hist / hist.sum()


def _add_speckle_noise(w: np.ndarray, snr_db: float,
                       rng: np.random.Generator) -> np.ndarray:
    """Multiplicative log-normal speckle noise at the given SNR."""
    sigma = 10 ** (-snr_db / 20)
    noise = rng.lognormal(mean=0, sigma=sigma, size=w.shape)
    out = w * noise
    return 100.0 * out / max(out.sum(), 1e-9)


def _inject_dust_spike(w: np.ndarray, grid_nm: np.ndarray,
                       rng: np.random.Generator, prob: float = 0.2) -> np.ndarray:
    """With probability prob, add a sharp peak above 5 um."""
    if rng.random() > prob:
        return w
    spike_d = rng.uniform(5000, 15000)
    idx = int(np.argmin(np.abs(grid_nm - spike_d)))
    amp = rng.uniform(0.05, 0.30) * w.max()
    out = w.copy()
    out[idx] += amp
    if idx + 1 < len(out):
        out[idx + 1] += amp * 0.5
    if idx - 1 >= 0:
        out[idx - 1] += amp * 0.5
    return 100.0 * out / max(out.sum(), 1e-9)


def bootstrap_perturb(real_dists: np.ndarray, real_labels: np.ndarray,
                      grid_nm: np.ndarray, target_class: int, n: int,
                      rng: np.random.Generator) -> list[np.ndarray]:
    """Sample real distributions of the target class and perturb them."""
    pool = real_dists[real_labels == target_class]
    if len(pool) == 0:
        return []
    out = []
    for _ in range(n):
        base = pool[rng.integers(0, len(pool))].copy()
        base = base * np.exp(rng.normal(0, 0.20, size=base.shape))
        shift = rng.integers(-2, 3)
        if shift != 0:
            base = np.roll(base, shift)
        base = _add_speckle_noise(base, snr_db=20, rng=rng)
        base = _inject_dust_spike(base, grid_nm, rng, prob=0.25)
        if base.sum() > 0:
            out.append(100.0 * base / base.sum())
    return out


def mixture_generate(grid_nm: np.ndarray, target_class: int, n: int,
                     rng: np.random.Generator) -> list[tuple[np.ndarray, dict]]:
    """Multi-modal lognormal mixtures with class-conditional priors."""
    out = []
    for _ in range(n):
        components = [(rng.uniform(5, 25),
                       rng.uniform(0.3, 0.6),
                       rng.uniform(0.05, 0.30))]
        if target_class == 0:
            if rng.random() < 0.4:
                components.append((rng.uniform(30, 200),
                                   rng.uniform(0.3, 0.5),
                                   rng.uniform(0.05, 0.20)))
        elif target_class == 1:
            components.append((rng.uniform(80, 600),
                               rng.uniform(0.4, 0.7),
                               rng.uniform(0.30, 0.60)))
        else:
            components.append((rng.uniform(200, 1500),
                               rng.uniform(0.5, 0.9),
                               rng.uniform(0.45, 0.75)))
            if rng.random() < 0.5:
                components.append((rng.uniform(2000, 8000),
                                   rng.uniform(0.4, 0.8),
                                   rng.uniform(0.10, 0.40)))

        amps = np.array([c[2] for c in components])
        amps = amps / amps.sum()
        w_total = np.zeros_like(grid_nm)
        for (mu, sig, _), a in zip(components, amps):
            w_total += a * _bin_lognormal(mu, sig, grid_nm, rng=rng)
        w_total = _add_speckle_noise(w_total, snr_db=22, rng=rng)
        w_total = _inject_dust_spike(w_total, grid_nm, rng, prob=0.15)
        meta = {"n_components": len(components),
                "modes": [round(c[0], 1) for c in components]}
        if w_total.sum() > 0:
            out.append((100.0 * w_total / w_total.sum(), meta))
    return out


def class_conditional_intensity(real_df: pd.DataFrame, target_class: int,
                                rng: np.random.Generator) -> float:
    """Draw an intensity in kcps from the empirical class-conditional
    distribution of the real cohort, with +-20% log-noise."""
    intensities = real_df.loc[real_df["y"] == target_class,
                              "mean_intensity_kcps"].values
    if len(intensities) == 0:
        return float(rng.uniform(50, 500))
    base = float(rng.choice(intensities))
    return float(base * rng.lognormal(0, 0.20))


def generate_dataset(real_csv: str, distributions_npz: str,
                     n_per_class_boot: int = 80,
                     n_per_class_mix: int = 70,
                     seed: int = 11) -> tuple[np.ndarray, list[SyntheticSample]]:
    """Produce n_per_class_boot bootstrap-perturb + n_per_class_mix mixture
    samples per class, evaluated on the same 142-bin grid as the real data.
    """
    rng = np.random.default_rng(seed)
    df = pd.read_csv(real_csv)
    df = df[~df["file"].str.startswith("C1_")].reset_index(drop=True)
    q33, q67 = df["mean_intensity_kcps"].quantile([1/3, 2/3])
    df["y"] = pd.cut(df["mean_intensity_kcps"],
                     bins=[-np.inf, q33, q67, np.inf],
                     labels=[0, 1, 2]).astype(int)

    arr = np.load(distributions_npz)
    grid = arr["diameter_nm"]
    real_dists = arr["intensity_weighted"]
    real_files = arr["files"]
    file_to_y = dict(zip(df["file"], df["y"]))
    real_labels = np.array([file_to_y.get(f, -1) for f in real_files])

    samples: list[SyntheticSample] = []
    for cls in [0, 1, 2]:
        for i, dist in enumerate(bootstrap_perturb(
                real_dists, real_labels, grid, cls, n_per_class_boot, rng)):
            cd, pdi = _cumulants_estimate(grid, dist)
            samples.append(SyntheticSample(
                name=f"BOOT_{['L','M','H'][cls]}_{i:03d}",
                target_class=cls,
                diameter_nm=grid,
                intensity_weighted=dist,
                cumulants_diameter_nm=cd,
                cumulants_pdi_pct=pdi,
                mean_intensity_kcps=class_conditional_intensity(df, cls, rng),
                source="bootstrap_perturb",
            ))

        for i, (dist, meta) in enumerate(mixture_generate(
                grid, cls, n_per_class_mix, rng)):
            cd, pdi = _cumulants_estimate(grid, dist)
            if meta["n_components"] >= 2:
                pdi = max(pdi, rng.uniform(60, 500))
            samples.append(SyntheticSample(
                name=f"MIX_{['L','M','H'][cls]}_{i:03d}",
                target_class=cls,
                diameter_nm=grid,
                intensity_weighted=dist,
                cumulants_diameter_nm=cd,
                cumulants_pdi_pct=pdi,
                mean_intensity_kcps=class_conditional_intensity(df, cls, rng),
                source="mixture",
            ))
    return grid, samples


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate synthetic DLS measurements")
    ap.add_argument("real_csv", help="Path to dls_features.csv")
    ap.add_argument("distributions_npz", help="Path to size_distributions.npz")
    ap.add_argument("-o", "--out_npz", default="data/synthetic/synthetic_augmented.npz")
    ap.add_argument("--n_boot", type=int, default=80,
                    help="Bootstrap-perturb samples per class (default 80)")
    ap.add_argument("--n_mix", type=int, default=70,
                    help="Mixture samples per class (default 70)")
    args = ap.parse_args()

    grid, samples = generate_dataset(args.real_csv, args.distributions_npz,
                                     n_per_class_boot=args.n_boot,
                                     n_per_class_mix=args.n_mix)
    Path(args.out_npz).parent.mkdir(parents=True, exist_ok=True)
    np.savez(args.out_npz,
             diameter_nm=grid,
             intensity_weighted=np.array([s.intensity_weighted for s in samples]),
             mean_intensity_kcps=np.array([s.mean_intensity_kcps for s in samples]),
             cumulants_diameter_nm=np.array([s.cumulants_diameter_nm for s in samples]),
             cumulants_pdi_pct=np.array([s.cumulants_pdi_pct for s in samples]),
             target_class=np.array([s.target_class for s in samples]),
             source=np.array([s.source for s in samples]),
             names=np.array([s.name for s in samples]))
    print(f"Generated {len(samples)} synthetic samples -> {args.out_npz}")


if __name__ == "__main__":
    main()
