"""Command-line prediction on a new DynaPro NanoStar XLSX file.

Prints, for each input file, the raw Cumulants scalars and the Stokes-
Einstein cross-check, the class prediction of both the primary MoE model
(with intensity) and the shape-only MoE model (without intensity), each
with its per-expert breakdown and gating weights, and the Milli-Q anomaly
distance.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from .extract_features import read_one
from .features import spectrum_features, stokes_einstein_diameter_nm

MODELS_DIR = Path("models")
CLASS_NAMES = ["Low", "Medium", "High"]


def featurise_xlsx(xlsx_path: str) -> pd.DataFrame:
    """Turn one XLSX file into a one-row engineered-feature DataFrame."""
    rec = read_one(xlsx_path)
    d_nm = rec["diameter_nm"]
    row = {k: rec.get(k) for k in rec if not isinstance(rec.get(k), np.ndarray)}
    row.update(spectrum_features(d_nm, rec["intensity_weighted"], "int"))
    row.update(spectrum_features(d_nm, rec["volume_weighted"], "vol"))
    row.update(spectrum_features(d_nm, rec["number_weighted"], "num"))
    row["d_stokes_einstein_nm"] = stokes_einstein_diameter_nm(
        row.get("diffusion_coef_um2_s"))
    if row.get("hydrodynamic_diameter_nm") is not None:
        row["d_se_minus_cumulants_nm"] = (row["d_stokes_einstein_nm"]
                                          - row["hydrodynamic_diameter_nm"])
    else:
        row["d_se_minus_cumulants_nm"] = np.nan
    row["cumulants_unreliable"] = int((row.get("polydispersity_pct") or 0) > 100)
    return pd.DataFrame([row])


def predict_with(bundle_path: Path, df: pd.DataFrame,
                 mask_intensity: bool = False) -> dict:
    if not bundle_path.exists():
        return {"error": f"missing {bundle_path.name}"}
    bundle = joblib.load(bundle_path)
    model = bundle["model"]
    df_in = df.copy()
    if mask_intensity and "mean_intensity_kcps" in df_in.columns:
        df_in["mean_intensity_kcps"] = 0.0
    proba = model.predict_proba(df_in)[0]
    pred = int(np.argmax(proba))
    gates = model.expert_gates(df_in)[0]
    expert_probs = model.expert_predict_proba(df_in)
    expert_summary = {}
    for i, spec in enumerate(model.experts):
        probs = expert_probs[spec.name][0]
        expert_summary[spec.name] = {
            "gate_weight": round(float(gates[i]), 3),
            "predicted_class": CLASS_NAMES[int(np.argmax(probs))],
            "probabilities": {CLASS_NAMES[j]: round(float(probs[j]), 3)
                              for j in range(3)},
        }
    return {
        "task": bundle.get("task", ""),
        "predicted_class": CLASS_NAMES[pred],
        "probabilities": {CLASS_NAMES[i]: round(float(p), 3)
                          for i, p in enumerate(proba)},
        "plausible_classes": [CLASS_NAMES[i] for i, p in enumerate(proba)
                              if p >= 0.20],
        "experts": expert_summary,
        "expected_accuracy": bundle.get("expected_cv_accuracy",
                                          bundle.get("expected_transfer_accuracy")),
    }


def milliq_anomaly_score(df_one: pd.DataFrame,
                         reference_csv: str = "data/processed/dls_engineered.csv"
                         ) -> float:
    """Euclidean z-distance in the (band fractions, D50) feature subspace
    from the mean of the three Milli-Q training samples."""
    p = Path(reference_csv)
    if not p.exists():
        return float("nan")
    ref = pd.read_csv(p)
    cols = ["int_frac_sub_10nm", "int_frac_10_100nm",
            "int_frac_100_1000nm", "int_frac_1_10um", "int_D50"]
    if any(c not in ref.columns or c not in df_one.columns for c in cols):
        return float("nan")
    pw = ref[ref["group"] == "PW"][cols].astype(float)
    if pw.empty:
        return float("nan")
    mu = pw.mean()
    sd = pw.std().replace(0, 1).fillna(1)
    sample = df_one.iloc[0][cols].astype(float)
    z = (sample - mu) / sd
    return float(np.sqrt((z ** 2).sum()))


def predict_one_file(xlsx_path: str) -> dict:
    df = featurise_xlsx(xlsx_path)
    out = {
        "file": os.path.basename(xlsx_path),
        "scalars": {
            "mean_intensity_kcps": float(df["mean_intensity_kcps"].iloc[0] or 0.0),
            "hydrodynamic_diameter_nm":
                float(df["hydrodynamic_diameter_nm"].iloc[0] or 0.0),
            "polydispersity_pct": float(df["polydispersity_pct"].iloc[0] or 0.0),
            "d_stokes_einstein_nm":
                float(df["d_stokes_einstein_nm"].iloc[0] or 0.0),
            "int_frac_10_100nm_pct":
                round(100 * float(df["int_frac_10_100nm"].iloc[0] or 0.0), 2),
            "int_frac_100_1000nm_pct":
                round(100 * float(df["int_frac_100_1000nm"].iloc[0] or 0.0), 2),
            "int_D50_nm": round(float(df["int_D50"].iloc[0] or 0.0), 1),
        },
        "primary_moe": predict_with(MODELS_DIR / "model_moe_primary.joblib", df),
        "shape_moe": predict_with(MODELS_DIR / "model_moe_shape.joblib", df,
                                  mask_intensity=True),
        "milliq_anomaly_distance": milliq_anomaly_score(df),
    }
    return out


def pretty(result: dict) -> None:
    print(f"\n=== {result['file']} ===")
    s = result["scalars"]
    print("  Raw DLS scalars:")
    print(f"    mean intensity     = {s['mean_intensity_kcps']:8.1f} kcps")
    print(f"    hydro diameter     = {s['hydrodynamic_diameter_nm']:8.1f} nm (Cumulants)")
    print(f"    Stokes-Einstein d  = {s['d_stokes_einstein_nm']:8.1f} nm (cross-check)")
    print(f"    polydispersity     = {s['polydispersity_pct']:8.1f} %")
    print(f"    D50                = {s['int_D50_nm']:8.1f} nm")
    print(f"    frac 10-100 nm     = {s['int_frac_10_100nm_pct']:8.2f} %")
    print(f"    frac 100-1000 nm   = {s['int_frac_100_1000nm_pct']:8.2f} %")
    for tag, key in [("PRIMARY (MoE-FULL, real cohort)", "primary_moe"),
                     ("SHAPE   (MoE-SHAPE, synthetic training)", "shape_moe")]:
        m = result.get(key, {})
        if "error" in m:
            print(f"  {tag}: {m['error']}")
            continue
        acc = m.get("expected_accuracy")
        acc_str = f"  (expected accuracy {acc:.1%})" if acc is not None else ""
        probs = "  ".join(f"{k}={v:.2f}" for k, v in m["probabilities"].items())
        plaus = ", ".join(m["plausible_classes"]) or "<none>"
        print(f"  {tag}{acc_str}")
        print(f"    -> predicted: {m['predicted_class']}  | {probs}")
        print(f"    -> plausible (p>=0.20): [{plaus}]")
        for ename, exp in m["experts"].items():
            ep = "  ".join(f"{k}={v:.2f}" for k, v in exp["probabilities"].items())
            print(f"       expert {ename:20s} gate={exp['gate_weight']:.3f}  "
                  f"says {exp['predicted_class']:<7s} ({ep})")
    if not np.isnan(result.get("milliq_anomaly_distance", float("nan"))):
        print(f"  Milli-Q anomaly distance: {result['milliq_anomaly_distance']:.3f} sigma")


def main() -> None:
    ap = argparse.ArgumentParser(description="Predict contamination class for new DLS measurements")
    ap.add_argument("path", help="XLSX file or directory of XLSX files")
    ap.add_argument("--json", action="store_true", help="emit JSON")
    args = ap.parse_args()

    if os.path.isdir(args.path):
        targets = sorted(glob.glob(os.path.join(args.path, "*.xlsx")))
    else:
        targets = [args.path]
    if not targets:
        sys.exit(f"No XLSX files found under {args.path}")

    results = [predict_one_file(t) for t in targets]
    if args.json:
        print(json.dumps(results, indent=2, default=float))
    else:
        for r in results:
            pretty(r)


if __name__ == "__main__":
    main()
