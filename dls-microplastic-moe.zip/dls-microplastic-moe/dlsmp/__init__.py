"""Feature extraction, mixture-of-experts classifier and synthetic-data
pipeline for DLS-based screening of sub-micron plastic particulates in
drinking water.
"""

__version__ = "1.0.0"
