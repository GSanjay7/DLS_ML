"""Cross-check the intensity-tertile labelling against Wei and Chua (2026).

Their supplementary table reports 89 DLS measurements of polystyrene (PS),
poly(methyl methacrylate) (PMMA) and polypropylene (PP) suspensions at
concentrations spanning five decades. We compute a Stokes-Einstein diameter
from the reported diffusion coefficient, rescale the intensity to kcps,
and apply the intensity-tertile cut points derived from our own cohort
(q33 = 291.6 kcps, q67 = 435.5 kcps).

The Spearman rank correlation between concentration and DLS intensity on
their data quantifies the external consistency of the labelling rule.

Requires:
    data/external/wei_chua_si.xlsx
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd

from .features import stokes_einstein_diameter_nm

SHEETS = ["PS", "PMMA", "PP"]


def load_reference(xlsx_path: str) -> pd.DataFrame:
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    rows = []
    for sn in SHEETS:
        ws = wb[sn]
        headers = None
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i == 0:
                headers = list(row)
                continue
            try:
                rec = {h: v for h, v in zip(headers, row) if h is not None}
                conc = rec.get("Item")
                conc = float(conc) if conc not in (None, "") else None
                intensity = rec.get("Intensity(Cnt/s)")
                intensity = float(intensity) if intensity not in (None, "") else None
                diff = rec.get("Diffusion Coefficient(cm?s)")
                diff = float(diff) if diff not in (None, "") else None
                if intensity is None or diff is None:
                    continue
                d_h = stokes_einstein_diameter_nm(diff * 1e8)
                rows.append({
                    "polymer": sn,
                    "concentration_mgmL": conc,
                    "intensity_kcps": intensity / 1000.0,
                    "diffusion_cm2_s": diff,
                    "d_stokes_einstein_nm": d_h,
                })
            except Exception:
                continue
    wb.close()
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser(description="Cross-check against Wei and Chua (2026)")
    ap.add_argument("--xlsx", default="data/external/wei_chua_si.xlsx")
    ap.add_argument("--engineered_csv",
                    default="data/processed/dls_engineered.csv")
    ap.add_argument("--out_json", default="external_validation.json")
    ap.add_argument("--out_csv", default="data/external/wei_chua_processed.csv")
    args = ap.parse_args()

    wc = load_reference(args.xlsx)
    print(f"Loaded {len(wc)} measurements across {wc['polymer'].nunique()} polymers")

    real = pd.read_csv(args.engineered_csv)
    real = real[~real["file"].str.startswith("C1_")]
    q33, q67 = real["mean_intensity_kcps"].quantile([1/3, 2/3])
    wc["our_class"] = pd.cut(wc["intensity_kcps"],
                             bins=[-np.inf, q33, q67, np.inf],
                             labels=["Low", "Medium", "High"])

    print(f"Our thresholds: q33 = {q33:.1f} kcps  q67 = {q67:.1f} kcps")
    print(wc.groupby(["polymer", "our_class"], observed=True).size()
          .unstack(fill_value=0))

    rho = wc[["concentration_mgmL", "intensity_kcps"]].corr(
        method="spearman").iloc[0, 1]
    print(f"\nSpearman rho (concentration vs intensity) = {rho:.3f}")

    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    wc.to_csv(args.out_csv, index=False)
    result = {
        "n_measurements": int(len(wc)),
        "polymers": wc["polymer"].value_counts().to_dict(),
        "intensity_range_kcps": [float(wc["intensity_kcps"].min()),
                                 float(wc["intensity_kcps"].max())],
        "our_q33_kcps": float(q33),
        "our_q67_kcps": float(q67),
        "spearman_intensity_vs_concentration": float(rho),
    }
    Path(args.out_json).write_text(json.dumps(result, indent=2, default=float))
    print(f"Saved -> {args.out_csv} and {args.out_json}")


if __name__ == "__main__":
    main()
