"""Regenerate figures 1, 3, and the pipeline diagram from processed data.

Usage: from the repository root,

    python scripts/make_figures.py
"""
from __future__ import annotations

from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dlsmp.domain_adapt import coral_align

FIG_DIR = Path("figures")
FIG_DIR.mkdir(exist_ok=True)


def fig1_distributions() -> None:
    arr = np.load("data/processed/size_distributions.npz")
    d = arr["diameter_nm"]
    groups = arr["groups"]
    intensity = arr["intensity_weighted"]

    unique_groups = sorted(set(groups.tolist()) - {"C"})
    fig, axes = plt.subplots(3, 3, figsize=(10, 7), sharex=True, sharey=True)
    for ax, grp in zip(axes.flat, unique_groups):
        idxs = np.where(groups == grp)[0]
        for i in idxs:
            ax.semilogx(d, intensity[i], lw=1.0, alpha=0.8)
        ax.set_title(grp, fontsize=10)
        ax.grid(True, which="both", alpha=0.3)
        ax.set_xlim(1, 2e4)
    for ax in axes[-1]:
        ax.set_xlabel("Diameter (nm)")
    for ax in axes[:, 0]:
        ax.set_ylabel("Intensity (%)")
    fig.suptitle("Intensity-weighted size distributions by sample group",
                 fontsize=11)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig1_distributions_by_group.png",
                dpi=180, bbox_inches="tight")
    plt.close(fig)


def fig2_pipeline() -> None:
    def box(ax, x, y, w, h, text, fc="#e6f0ff", ec="#1f3a68", fs=8.5):
        p = FancyBboxPatch((x, y), w, h,
                           boxstyle="round,pad=0.02,rounding_size=0.04",
                           facecolor=fc, edgecolor=ec, linewidth=1.2)
        ax.add_patch(p)
        ax.text(x + w / 2, y + h / 2, text,
                ha="center", va="center", fontsize=fs)

    def arrow(ax, x1, y1, x2, y2):
        a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                            mutation_scale=10, color="#444", lw=1.0)
        ax.add_patch(a)

    fig, ax = plt.subplots(figsize=(9.2, 7.6))
    ax.set_xlim(0, 10); ax.set_ylim(0, 9); ax.axis("off")

    box(ax, 3.5, 8.0, 3.0, 0.65,
        "DLS measurement (XLSX)\nDynaPro NanoStar",
        fc="#fff4d6", ec="#a07000")
    box(ax, 0.6, 6.6, 3.6, 0.95,
        "Cumulants scalars (13)\nintensity, diameter, PDI,\n"
        "g^2, fit error, peaks",
        fc="#eaf6e1", ec="#3b7a1f")
    box(ax, 4.5, 6.6, 4.8, 0.95,
        "Intensity-weighted size distribution\n"
        "142 log-spaced bins, 0.21 nm to 19 um",
        fc="#eaf6e1", ec="#3b7a1f")
    arrow(ax, 5.0, 8.0, 2.4, 7.55)
    arrow(ax, 5.0, 8.0, 6.9, 7.55)

    box(ax, 0.4, 5.0, 4.0, 1.2,
        "Engineered features (62)\n. Distribution moments on log10(d)\n"
        ". Percentiles D10 / D50 / D90\n. Band fractions (4)\n"
        ". Mode count, Shannon entropy\n. Stokes-Einstein cross-check",
        fc="#e8eefb", ec="#1f3a68")
    box(ax, 5.0, 5.0, 4.6, 1.2,
        "Synthetic augmentation (450)\n"
        ". Multi-modal lognormal mixtures (210)\n"
        ". Empirical bootstrap-perturb (240)\n"
        ". Class-conditional intensity\n"
        ". Speckle noise, dust spikes",
        fc="#fbeaea", ec="#7a1f1f")
    arrow(ax, 2.4, 6.6, 2.4, 6.2)
    arrow(ax, 6.9, 6.6, 6.9, 6.2)
    arrow(ax, 6.9, 5.0, 4.4, 5.0)

    box(ax, 0.4, 3.4, 9.2, 1.3,
        "Mixture-of-experts classifier\n\n"
        "Expert 1: Scalars (Random Forest)   "
        "Expert 2: Bands (XGBoost)   "
        "Expert 3: Shape (LightGBM)\n"
        "Trained on real + CORAL-aligned synthetic, "
        "sample weights 1.0 / 0.5",
        fc="#ebe6fb", ec="#3a1f6b")
    arrow(ax, 2.4, 5.0, 2.4, 4.7)
    arrow(ax, 5.0, 5.0, 5.0, 4.7)

    box(ax, 1.5, 1.8, 3.5, 1.0,
        "Gating MLP (2 layers, 32 hidden)\n"
        "Inputs: g^2, fit error, PDI %,\n"
        "peak area, fit-failure flag",
        fc="#fff2e0", ec="#a05000")
    box(ax, 5.5, 1.8, 3.5, 1.0,
        "Combination rule\n"
        "log P(y|x) = log sum_i g_i P_i\n"
        "Focal cross-entropy, gamma = 2",
        fc="#fff2e0", ec="#a05000")
    arrow(ax, 3.2, 3.4, 3.2, 2.8)
    arrow(ax, 7.0, 3.4, 7.0, 2.8)

    box(ax, 2.5, 0.2, 5.0, 1.1,
        "Output\nP(Low), P(Medium), P(High)\n"
        "Per-expert breakdown + gating weights\n"
        "Milli-Q anomaly distance (IsolationForest)",
        fc="#e8eefb", ec="#1f3a68")
    arrow(ax, 5.0, 1.8, 5.0, 1.3)

    ax.text(0.4, 8.6, "Pipeline architecture", fontsize=11, weight="bold")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig2_pipeline_architecture.png",
                dpi=180, bbox_inches="tight")
    plt.close(fig)


def fig3_coral_alignment() -> None:
    real = pd.read_csv("data/processed/dls_engineered.csv")
    real = real[~real["file"].str.startswith("C1_")].reset_index(drop=True)
    cols = ["int_D50", "int_log10d_std", "int_frac_100_1000nm",
            "polydispersity_pct"]

    syn_arr = np.load("data/synthetic/synthetic_augmented.npz")
    from dlsmp.features import spectrum_features
    syn_rows = []
    for i in range(len(syn_arr["target_class"])):
        feats = spectrum_features(syn_arr["diameter_nm"],
                                  syn_arr["intensity_weighted"][i], "int")
        feats["polydispersity_pct"] = float(syn_arr["cumulants_pdi_pct"][i])
        syn_rows.append(feats)
    syn = pd.DataFrame(syn_rows)

    X_real = real[cols].astype(float).fillna(0).to_numpy()
    X_syn = syn[cols].astype(float).fillna(0).to_numpy()
    X_syn_aligned = coral_align(X_syn, X_real, eps=1e-2)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
    axes[0].scatter(np.log10(np.maximum(X_real[:, 0], 1)), X_real[:, 1],
                    c="#1f3a68", s=35, label="Real (n=27)",
                    alpha=0.85, edgecolors="white")
    axes[0].scatter(np.log10(np.maximum(X_syn[:, 0], 1)), X_syn[:, 1],
                    c="#a04000", s=14, label="Synthetic raw (n=450)",
                    alpha=0.35)
    axes[0].set_xlabel("log10 D50 (nm)")
    axes[0].set_ylabel("sigma(log10 d)")
    axes[0].set_title("Before CORAL")
    axes[0].legend(fontsize=8); axes[0].grid(alpha=0.3)

    axes[1].scatter(np.log10(np.maximum(X_real[:, 0], 1)), X_real[:, 1],
                    c="#1f3a68", s=35, label="Real (n=27)",
                    alpha=0.85, edgecolors="white")
    axes[1].scatter(np.log10(np.maximum(X_syn_aligned[:, 0], 1)),
                    X_syn_aligned[:, 1],
                    c="#2a7a3a", s=14, label="Synthetic CORAL-aligned",
                    alpha=0.35)
    axes[1].set_xlabel("log10 D50 (nm)")
    axes[1].set_ylabel("sigma(log10 d)")
    axes[1].set_title("After CORAL alignment")
    axes[1].legend(fontsize=8); axes[1].grid(alpha=0.3)

    fig.suptitle("CORAL covariance alignment of synthetic to real",
                 fontsize=11)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig3_coral_alignment.png",
                dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    fig1_distributions()
    fig2_pipeline()
    fig3_coral_alignment()
    print(f"Wrote figures to {FIG_DIR}")


if __name__ == "__main__":
    main()
